<?php?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <?php include 'styling.php';?>

	<title>ATTENDANCE MANAGER</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Optional Bootstrap theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">




<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Optional Bootstrap theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<link href="style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/arial.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
</head>
<body>
<div class="main">
  <?php include 'header.php';?>

  <div class="head">
		<h2>Teacher Data</h2>
	</div>
	
  <div class="content1">
    <div class="content_resize">
		
<form method="post" action="batch_insert_teacher.php" enctype="multipart/form-data"> 
		<div >
        <label>Choose CSV File</label> 
				<input type="file" name="file" id="file" accept=".csv">
        <button type="submit" id="submit" name="import" class="btn-submit">Import</button>
        <br />

    </div>
		</form>	
       <form method="post" action="teacher_insert.php">
	    <div class="input-group">
			<label>Employee Id</label>
			<input type="text" name="Employee_Id" placeholder="eg. NED-0000-12121" >
		</div>
        <div class="input-group">
			<label>Name</label>
			<input type="text" name="Teacher_Name" >
		</div>
		<div class="input-group">
			<label>Father Name</label>
			<input type="text" name="Father_Name" >
		</div>
		<div class="input-group">
			<label>Gender</label>
			<input type="text" name="Gender" >
		</div>
		<div class="input-group">
			<label>Cell no.</label>
			<input type="text" name="Cell_No" placeholder="eg. 03002915572">
		</div>

		<div class="input-group">
			<label>Email</label>
			<input type="email" name="Email" placeholder="eg. xyz@ned.com">
		</div>
		
		<div class="input-group">
			<label>Password</label>
			<input type="text" name="PasswordHash"  >
		</div>
		
		<div class="input-group">
			<label>Address</label>
			<input type="text" name="Address" placeholder=" eg. House No 111-A,Gulshane-e-Iqbal">
		</div>
		
		<div class="input-group">
			<button type="submit" name="reg_user">SAVE</button>
		</div>
		
	</form>

      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
	     
      <div class="clr"></div>
    </div>
  </div>
     <?php include 'footer.php';?>

</div>
</html>
