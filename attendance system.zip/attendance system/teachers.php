<?php?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>ATTENDANCE MANAGER</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Optional Bootstrap theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<link href="styling.css" rel="stylesheet" type="text/css" />

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 
</head>


<body>
<div class="main">
  <?php include 'header.php';?>

  <div class="head">
		<h2>Teacher Data</h2>
	</div>
	
  <div class="content1">
    <div class="content_resize">
		
<form method="post" action="batch_insert_teacher.php" enctype="multipart/form-data"> 
		<div >
        <label>Choose CSV File</label> 
				<input type="file" name="file" id="file" accept=".csv">
        <button type="submit" id="submit" name="import" class="btn-submit">Import</button>
        <br />

    </div>
		</form>	
		<script>
function validate(){
	if((document.myForm.Employee_Id.value=="") || !isNaN(document.myForm.Employee_Id.value))
{
document.getElementById("Employee_Id_error").innerHTML="No Employee Id provided";
document.myForm.Employee_Id.focus();
return false;
}

   if((document.myForm.Teacher_Name.value=="") || !isNaN(document.myForm.Teacher_Name.value))
{
document.getElementById("Teacher_Name_error").innerHTML="No Teacher Name provided";
document.myForm.Teacher_Name.focus();
return false;
}
if((document.myForm.Father_Name.value=="") || !isNaN(document.myForm.Father_Name.value))
{
document.getElementById("Father_Name_error").innerHTML="No Father_Name provided";
document.myForm.Father_Name.focus();
return false;
}
if((document.myForm.Gender.value=="") || !isNaN(document.myForm.Gender.value))
{
document.getElementById("Gender_error").innerHTML="No Gender No provided";
document.myForm.Gender.focus();
return false;
}
var Cell=document.myForm.Cell_No.value;
   if((Cell=="") || isNaN(Cell)){
document.getElementById("Cell_error").innerHTML="No vaild Cell No provided";
return false;}
if((document.myForm.Email.value=="") || !isNaN(document.myForm.Email.value))
{
document.getElementById("Email_error").innerHTML="No Email provided";
document.myForm.Email.focus();
return false;
}
if((document.myForm.PasswordHash.value=="") || !isNaN(document.myForm.PasswordHash.value))
{
document.getElementById("PasswordHash_error").innerHTML="No Password Name provided";
document.myForm.PasswordHash.focus();
return false;
}
if((document.myForm.Address.value=="") || !isNaN(document.myForm.Address.value))
{
document.getElementById("Address_error").innerHTML="No Address provided";
document.myForm.Address.focus();
return false;
}
else {
 document.getElementById("Employee_Id_error").innerHTML="";
 document.getElementById("Teacher_Name_error").innerHTML="";
 document.getElementById("Father_Name_error").innerHTML="";
 document.getElementById("Gender_error").innerHTML="";
 document.getElementById("Cell_error").innerHTML="";
 document.getElementById("Email_error").innerHTML="";
 document.getElementById("PasswordHash_error").innerHTML="";
 document.getElementById("Address_error").innerHTML="";
return true;
}                 
            }
</script>

       <form name="myForm" onsubmit="return(validate());" method="post" action="teacher_insert.php">
	    <div class="input-group">
			<label for="Employee_Id">Employee Id</label><SPAN STYLE=color:red ID="Employee_Id_error"></SPAN>
			<input type="text" name="Employee_Id" placeholder="eg. NED-0000-12121" >
		</div>
        <div class="input-group">
			<label for="Teacher_Name">Name</label><SPAN STYLE=color:red ID="Teacher_Name_error"></SPAN>
			<input type="text" name="Teacher_Name" >
		</div>
		<div class="input-group">
			<label for="Father_Name">Father Name</label><SPAN STYLE=color:red ID="Father_Name_error"></SPAN>
			<input type="text" name="Father_Name" >
		</div>
		<div class="input-group">
			<label for="Gender">Gender</label><SPAN STYLE=color:red ID="Gender_error"></SPAN>
			<input type="text" name="Gender" >
		</div>
		<div class="input-group">
			<label for="Cell_No">Cell no.</label><SPAN STYLE=color:red ID="Cell_error"></SPAN>
			<input type="text" name="Cell_No" placeholder="eg. 03002915572">
		</div>

		<div class="input-group">
			<label for="Email">Email</label><SPAN STYLE=color:red ID="Email_error"></SPAN>
			<input type="email" name="Email" placeholder="eg. xyz@ned.com">
		</div>
		
		<div class="input-group">
			<label for="PasswordHash">Password</label><SPAN STYLE=color:red ID="PasswordHash_error"></SPAN>
			<input type="text" name="PasswordHash"  >
		</div>
		
		<div class="input-group">
			<label for="Address">Address</label><SPAN STYLE=color:red ID="Address_error"></SPAN>
			<input type="text" name="Address" placeholder=" eg. House No 111-A,Gulshane-e-Iqbal">
		</div>
		
		<div class="input-group">
			<button type="submit" name="reg_user">SAVE</button>
		</div>
		
	</form>

      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
	     
      <div class="clr"></div>
    </div>
  </div>
     <?php include 'footer.php';?>

</div>
</html>
