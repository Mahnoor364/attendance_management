<?php
echo'
<style>
body{
	border: 1px #0C9AC8;
	border-style:double;
	border-bottom: none;
	border-radius: 10px 10px 10px 10px;
	padding: 20px;

}
.head {
	width: 50%;
	color: white;
	background: #0C9AC8;
	text-align: center;
	border: 1px solid black;
	border-bottom: none;
	border-radius: 10px 10px 10px 10px;
	padding: 20px;
	margin-left:329px;
    margin-top:10px;
}
h2
{
    font-family: Arial, Helvetica, sans-serif;
} 
th,tr,td {
    border: 1px solid black;
    border-collapse: collapse;
}

form
{
	width: 50%;
	margin: 10px ;
	background: white;
}
 .content1 {
	width: 50%;
	margin: 10px auto;
	padding:10px;
	border: 1px solid #0C9AC8;
	background: white;
	border-radius: 10px 10px 10px 10px;
}
.input-group {
	margin: 10px 0px 10px 0px;
}

.input-group label {
	display: block;
	text-align: left;
	margin: 5px;
}
.input-group input {
	height: 40px;
	width: 500px;
	padding: 5px 10px;
	font-size: 16px;
	border-radius: 5px;
	border: 1px solid #0C9AC8;
}
.btn-submit{
	margin-top:10px;
}
.footer {
	background:#fff url(images/footer_bg.gif) repeat-x center top;
}
.footer_resize {
	margin:0 auto;
	padding:26px;
	width:922px;
	color:#959595;
}
.footer p {
	margin:0;
	padding:4px 0;
}
.footer a {
	color:#959595;
	text-decoration:underline;
}
.footer a:hover {
	text-decoration:none;
}
.footer .lf {
	float:left;
}
.footer .rf {
	float:right;
}

</style>';
?>