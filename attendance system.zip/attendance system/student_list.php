<?php?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>ATTENDANCE MANAGER</title>
   <?php include 'styling.php';?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Optional Bootstrap theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="main">
    <?php include 'header.php';?>

  <div class="head">
		<h2>Student List</h2>
	</div>
	
  <div class="content1">
    <div class="content_resize"> 
	

    <?php
		$servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "attendance_management";
        try {
                $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                // set the PDO error mode to exception
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                }
        catch(PDOException $e)
                {
               
                }

        $sql = $conn->prepare("SELECT s.Enrollment_No as Enrollment_No,
         s.Student_Name as Student_Name, s.Roll_No as Roll_No, p.Program_Name as Program_Name
         FROM student s 
         INNER JOIN program p 
         ON s.Program_Id = p.Program_Id");
        $sql->execute();

        $students = $sql->fetchAll();
        echo "<table style='margin:0px auto'>
        <tr>
        <th>Enrollment No.</th>
        <th>Student Name</th>
        <th>Roll No</th>
        <th>Program </th>
        </tr>
        ";
        if(count($students) != 0)
        {
         
            foreach($students as $student)
            {
                echo "<tr><td>". $student['Enrollment_No']
                ."</td><td>" .$student['Student_Name']
                ."</td><td>" .$student['Roll_No']
                ."</td><td>" .$student['Program_Name']
                ."</tr>";
            }
          
        }
        else 
        {
            echo "No students.";
        }

        echo "</table>";
    ?>
    
    

      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
      <div class="clr"></div>
    </div>
  </div>
      <?php include 'footer.php';?>

</div>
</html>
