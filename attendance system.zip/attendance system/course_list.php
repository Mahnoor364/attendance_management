<?php?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>ATTENDANCE MANAGER</title>
   <?php include 'styling.php';?>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Optional Bootstrap theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

</head>
<body>
<div class="main">
   <?php include 'header.php';?>

  <div class="head">
		<h2>Course List</h2>
	</div>
	
  <div class="content1">
    <div class="content_resize"> 
	

    <?php
		$servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "attendance_management";

        try {
                $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                // set the PDO error mode to exception
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                }
        catch(PDOException $e)
                {
               
                }

        $sql = $conn->prepare("SELECT Course_Code,Course_name,Credit_Hours,Practical_Hours FROM course");
        $sql->execute();

        $courses = $sql->fetchAll();
        echo "<table style='margin:0px auto'>
        <tr>
        <th>Course Code</th>
        <th>Course name</th>
        <th>Credit Hours</th>
        <th>Practical Hours</th>
        </tr>
        ";
        if(count($courses) != 0)
        {
         
            foreach($courses as $courses)
            {
                echo "<tr><td>". $courses['Course_Code']
                ."</td><td>" . $courses['Course_name']
                ."</td><td>" . $courses['Credit_Hours']
                ."</td><td>" . $courses['Practical_Hours']
                ."</tr>";
            }
          
        }
        else 
        {
            echo "No courses.";
        }

        echo "</table>";
    ?>
    
    

      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
      <div class="clr"></div>
    </div>
  </div>
       <?php include 'footer.php';?>

</div>
</html>
