<?php 
echo'
<div class="header">
    <div class="header_resize">
      <div class="menu_nav">
        <ul>
          <li><a href="home.php">Home</a></li>
          <li><a>Student</a>
		  <ul>
		  <li> <a href="students.php">Add Student </a></li>
		  <li> <a href="student_list.php">View Student </a></li>
          </ul>
		  </li>
          <li><a>Teacher</a>
		  <ul>
		  <li> <a href="teachers.php">Add Teacher </a></li>
		  <li> <a href="teacher_list.php">View Teacher </a></li>
          </ul>
		  </li>
          <li><a>Course</a>
		  <ul>
		  <li> <a href="courses.php">Add Course </a></li>
		  <li> <a href="course_list.php">View Course </a></li>
          </ul>
		  </li>
		  
		  <li><a href="session_menu.php">Session</a></li>

          <li style="float:right;" ><a href="login.php">LogOut</a></li>
        </ul>
      </div>
      <div class="clr"></div>
      </div>';
	?>