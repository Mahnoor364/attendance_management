<?php?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <?php include 'styling.php';?>
	<title>ATTENDANCE MANAGER</title>	
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Optional Bootstrap theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<link href="style.css" rel="stylesheet" type="text/css" />

</head>
<body>

<div class="main">
    <?php include 'header.php';?>

  <div class="head">
		<h2>Course Data</h2>
	</div>
	
  <div class="content1">
    <div class="content_resize"> 
		<!-- CSV INSERT CODE -->
		<form method="post" action="batch_insert_course.php" enctype="multipart/form-data"> 
		<div >
        <label>Choose CSV File</label> 
				<input type="file" name="file" id="file" accept=".csv">
        <button type="submit" id="submit" name="import" class="btn-submit">Import</button>
        <br />

    </div>
		</form>	
    <form method="post" action="course_insert.php">
        <div class="input-group">
			<label>Course Code</label>
			<input type="text"  name="Course_Code">
		</div>
		<div class="input-group">
			<label>Name</label>
			<input type="text" name="Course_name">
		</div>
		<div class="input-group">
			<label>Credit Hours</label>
			<input type="text" name="Credit_Hours">
		</div>
		<div class="input-group">
			<label>Practical Credit Hours</label>
			<input type="text" name="Practical_Hours">
		</div>
		
		
		
		
		<?php
			
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "attendance_management";
			try {
					$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
					// set the PDO error mode to exception
					$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					echo "Connected successfully"; 
					}
			catch(PDOException $e)
					{
					echo "Connection failed: " . $e->getMessage();
					}
			?>

		<div class="input-group">
			<label>Program course belongs to</label>
				<select name="program" >
				<?php
					try{
						$sql = 	$conn->prepare("Select Program_Id, Program_Name from program");
						$sql->execute();
						$programs = $sql->fetchAll();
				
						foreach($programs as $program)
						{
							echo "<option value='" . $program['Program_Id']. "'>" . $program['Program_Name']. "</option>";
						}
					}
					catch(PDOException $e)
					{
						echo "Error: " . $e->getMessage();
					}
					
				?>
				</select>
		</div>





		<div class="input-group">
			<button type="submit"  name="reg_user">SAVE</button>
		</div>
		
	</form>

      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
      <div class="clr"></div>
    </div>
  </div>
      <?php include 'footer.php';?>

</div>
</body>
</html>