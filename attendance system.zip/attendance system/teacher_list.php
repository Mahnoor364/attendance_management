<?php?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>ATTENDANCE MANAGER</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link href="styling.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Optional Bootstrap theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

</head>
<body>
<div class="main">
   <?php include 'header.php';?>

  <div class="head">
		<h2>Teacher List</h2>
	</div>
	
  <div class="content1">
    <div class="content_resize"> 
	

    <?php
		$servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "attendance_management";

        try {
                $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                // set the PDO error mode to exception
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                }
        catch(PDOException $e)
                {
               
                }

        $sql = $conn->prepare("SELECT Employee_Id, Teacher_Name, Father_Name, Email FROM teacher");
        $sql->execute();

        $teachers = $sql->fetchAll();
        echo "<table style='margin:0px auto'>
        <tr>
        <th>Employee Id</th>
        <th>Teacher Name</th>
        <th>Father Name</th>
        <th>Email</th>
        </tr>
        ";
        if(count($teachers) != 0)
        {
         
            foreach($teachers as $teacher)
            {
                echo "<tr><td>". $teacher['Employee_Id']
                ."</td><td>" . $teacher['Teacher_Name']
                ."</td><td>" . $teacher['Father_Name']
                ."</td><td>" . $teacher['Email']
                ."</tr>";
            }
          
        }
        else 
        {
            echo "No teachers.";
        }

        echo "</table>";
    ?>
    
    

      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
      <div class="clr"></div>
    </div>
  </div>
       <?php include 'footer.php';?>

</div>
</html>
