<?php?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>ATTENDANCE MANAGER</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Optional Bootstrap theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
	<link href="styling.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

</head>
<body>
<div class="main">
  <?php include 'header.php';?>

  <div class="head">
		<h2>Student Data</h2>
	</div>
  <div class="content1">
    <div class="content_resize">
	
<form method="post" action="batch_insert_student.php" enctype="multipart/form-data"> 
		<div >
        <label>Choose CSV File</label> 
				<input type="file" name="file" id="file" accept=".csv">
        <button type="submit" id="submit" name="import" class="btn-submit">Import</button>
        <br />

    </div>
		</form>	
		
<script>
function validate(){
	if((document.myForm.Student_Name.value=="") || !isNaN(document.myForm.Student_Name.value))
{
document.getElementById("Student_Name_error").innerHTML="No Student Name provided";
document.myForm.Student_Name.focus();
return false;
}

if((document.myForm.Father_Name.value=="") || !isNaN(document.myForm.Father_Name.value))
{
document.getElementById("Father_Name_error").innerHTML="No Father_Name provided";
document.myForm.Father_Name.focus();
return false;
}
if((document.myForm.Enrollment_No.value=="") || !isNaN(document.myForm.Enrollment_No.value))
{
document.getElementById("Enrollment_No_error").innerHTML="No Enrollment No provided";
document.myForm.Enrollment_No.focus();
return false;
}
   if((document.myForm.Batch.value=="") || !isNaN(document.myForm.Batch.value))
{
document.getElementById("Batch_error").innerHTML="No Batch provided";
document.myForm.Batch.focus();
return false;
}
 
if((document.myForm.Roll_No.value=="") || !isNaN(document.myForm.Roll_No.value))
{
document.getElementById("Roll_No_error").innerHTML="No Roll No provided";
document.myForm.Roll_No.focus();
return false;
}

if((document.myForm.Gender.value=="") || !isNaN(document.myForm.Gender.value))
{
document.getElementById("Gender_error").innerHTML="No Gender No provided";
document.myForm.Gender.focus();
return false;
}
var SCell=document.myForm.Student_Cell.value;
   if((SCell=="") || isNaN(SCell)){
document.getElementById("SCell_error").innerHTML="No vaild Student Cell provided";
return false;}
var PCell=document.myForm.Parent_Cell.value;
   if((PCell=="") || isNaN(PCell)){
document.getElementById("PCell_error").innerHTML="No vaild Parent Cell provided";
return false;}
if((document.myForm.Parent_Email.value=="") || !isNaN(document.myForm.Parent_Email.value))
{
document.getElementById("Parent_Email_error").innerHTML="No Parent Email provided";
document.myForm.Parent_Email.focus();
return false;
}
if((document.myForm.Address.value=="") || !isNaN(document.myForm.Address.value))
{
document.getElementById("Address_error").innerHTML="No Address provided";
document.myForm.Address.focus();
return false;
}
else {
 document.getElementById("Student_Name_error").innerHTML="";
 document.getElementById("Father_Name_error").innerHTML="";
 document.getElementById("Enrollment_No_error").innerHTML="";
 document.getElementById("Batch_error").innerHTML="";
    document.getElementById("Roll_No_error").innerHTML="";
	    document.getElementById("Gender_error").innerHTML="";
    document.getElementById("SCell_error").innerHTML="";
document.getElementById("PCell_error").innerHTML="";
 document.getElementById("Parent_Email_error").innerHTML="";
 document.getElementById("Address_error").innerHTML="";
return true;
}                 
            }
</script>


	      <form name="myForm" onsubmit="return(validate());" method="post" action="student_insert.php" >

	  
	<div class="input-group">
			<label>Name</label><SPAN STYLE=color:red ID="Student_Name_error"></SPAN>
			<input type="text" name="Student_Name" >
		</div>
		<div class="input-group">
			<label>Father Name</label><SPAN STYLE=color:red ID="Father_Name_error"></SPAN>
			<input type="text" name="Father_Name" >
		</div>
		<div class="input-group">
			<label>Enrollment No.</label><SPAN STYLE=color:red ID="Enrollment_No_error"></SPAN>
			<input type="text" name="Enrollment_No" placeholder="eg. NED/0615/13-14" >
		</div>
			
		
		
		<?php
			
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "attendance_management";

			try {
					$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
					// set the PDO error mode to exception
					$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					echo "Connected successfully"; 
					}
			catch(PDOException $e)
					{
					echo "Connection failed: " . $e->getMessage();
					}
			?>

		<div class="input-group">
			<label>Program course belongs to</label>
				<select name="program" >
				<?php
					try{
						$sql = 	$conn->prepare("Select Program_Id, Program_Name from program");
						$sql->execute();
						$programs = $sql->fetchAll();
				
						foreach($programs as $program)
						{
							echo "<option value='" . $program['Program_Id']. "'>" . $program['Program_Name']. "</option>";
						}
					}
					catch(PDOException $e)
					{
						echo "Error: " . $e->getMessage();
					}
					
				?>
				</select>
		</div>




		 <div class="input-group">
			<label>Batch Year</label><SPAN STYLE=color:red ID="Batch_error"></SPAN>
			<input type="text" name="Batch" placeholder="eg. 14-15" >
		</div>
		<div class="input-group">
			<label>Section</label>
			<input type="text" name="Section" placeholder="eg. 1 or 2" >
		</div>
		<div class="input-group">
			<label>Roll no.</label><SPAN STYLE=color:red ID="Roll_No_error"></SPAN>
			<input type="text" name="Roll_No" placeholder="eg. CT-064" >
		</div>
		<div class="input-group">
			<label>Gender</label><SPAN STYLE=color:red ID="Gender_error"></SPAN>
			<input type="text" name="Gender" >
		</div>
		<div class="input-group">
			<label>Cell no.</label><SPAN STYLE=color:red ID="SCell_error"></SPAN>
			<input type="text" name="Student_Cell" placeholder="eg. 03002915562" >
		</div>
		<div class="input-group">
			<label>Parent Cell no.</label><SPAN STYLE=color:red ID="PCell_error"></SPAN>
			<input type="text" name="Parent_Cell" placeholder="eg.03002915562" >
		</div>
		<div class="input-group">
			<label>Parent Email</label><SPAN STYLE=color:red ID="Parent_Email_error"></SPAN>
			<input type="email" name="Parent_Email" placeholder="abc@xyz.com" >
		</div>
		<div class="input-group">
			<label>Address</label><SPAN STYLE=color:red ID="Address_error"></SPAN>
			<input type="text" name="Address" placeholder=" eg. House No 111-A,Gulshane-e-Iqbal" >
		</div>
		
				<div class="input-group">
			<button type="submit" name="reg_user">SAVE</button>
		</div>
		
	</form>
    
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
	  <div class="clr"></div>
    </div>
  </div>
     <?php include 'footer.php';?>

</div>
</html>
